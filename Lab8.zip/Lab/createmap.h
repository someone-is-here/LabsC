//#ifndef CREATEMAP_H
//#define CREATEMAP_H
//#include <QDebug>
//#include <QPaintEvent>
//#include <QWidget>
//#include "request.h"

//class CreateMap: public QWidget{
//private:
//    int FromDoubleIntoScale(double value, double min, double max, int field);
//public:
//    CreateMap();
//    void paintEvent(QPaintEvent * /* event */);
//};

//#endif // CREATEMAP_H
